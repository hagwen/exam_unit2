# One step at at time

In this assignment you will be working with a server. The server will give you tasks and validate your answers.    

**You must get your personal ID for the assignment from https://mm-203-module-2-server.onrender.com/**

The tasks are not meant to be difficult, but every time you run your program the same task will have different parameters. This is to prevent hardcoded solutions.

The example shows one way to solve the task. You do not have to work the same way. You should consider the example as a bad/mediocre solution.

Make it work, make it right, make it better. In that order.  
Consider using all the knowledge you have to make the best solution you can.

**Do not mixup the example and the template"**

Submit URL to your git repository.
